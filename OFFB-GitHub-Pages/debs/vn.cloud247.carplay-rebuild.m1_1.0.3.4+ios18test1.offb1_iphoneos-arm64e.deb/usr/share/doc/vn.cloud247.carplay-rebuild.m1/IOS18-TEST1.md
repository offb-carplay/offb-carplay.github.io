> Ghi chú OFFB: tài liệu dưới đây mô tả nền CarFlow test1. Bản OFFB đã đổi tài nguyên logo, tên/liên hệ, các chuỗi hiển thị trong ba binary và ký lại các binary đó. Mã lệnh, entitlement, máy chủ và cơ chế license giữ nguyên; xem OFFB-README.md và OFFB-branding-report.json.

# CarFlow thử nghiệm cầu nối iOS 18 test1

Đây là bản ghép thử **CarFlow 1.0.3.4+ios18test1**, dành cho cách đóng gói Sileo/RootHide của gói CarFlow gốc. Bản thử thêm thư viện `CPR00IOS18Compat.dylib`; giữ nguyên các binary, cấu hình giấy phép và máy chủ của CarFlow. Không đưa các dylib của OmniCar vào chạy cùng CarFlow.

**Phạm vi:** cầu nối tên lớp, selector hình học và thông báo vòng đời controller của CarPlay trên iOS 18. Đây chưa phải bản chuyển toàn bộ tính năng/hành vi iOS 18 của OmniCar. Chưa cài hay chạy trên thiết bị iOS trong phiên này.

Người dùng cho biết đang có iPhone 12/iOS 16 và iPhone 15 Plus/iOS 17, cài bằng Sileo/RootHide. Thư viện mới **không cài hook trên iOS 16/17**. Hai máy này dùng để kiểm tra cài đặt và tác động lên bản CarFlow cũ; cần thiết bị iOS 18 để kiểm tra nhánh mới.

## Đã ghép gì

1. Trên iOS 18, ánh xạ `DBDashboard sceneFrameForApplication:proxyApplication:` qua selector cũ `sceneFrameForAppInfo:proxyAppInfo:` để các hook CarFlow hiện có có thể xử lý. Tương tự cho `safeAreaInsetsForApplication:proxyApplication:`.
2. Tạo alias cũ chỉ khi API mới có đúng kiểu trả về và tham số, còn API cũ chưa tồn tại. Nếu API cũ đã có, không thêm một chuỗi hook hình học thứ hai.
3. Giới hạn fallback `DBApplicationSceneViewController` sang `DBApplicationViewController` cho các lời gọi từ **CPRCarPlayHost.dylib**. Các tiến trình/tệp khác vẫn nhận kết quả tra cứu gốc.
4. Quan sát coordinator `CPRNativeScale` bằng weak reference. Chỉ thông báo layout/appear/invalidation của controller mới khi coordinator gốc xác nhận phiên đang hợp lệ. Trên controller còn entry point cũ, để CarFlow tự cài các callback, tránh gọi lặp.
5. Không chép lại hook `FBScene`, vì chúng đã có trong CarFlow gốc. Không mở khóa hoặc thay đổi luồng xác thực license.

Cơ sở đối chiếu: OmniCar 1.0.6 có các API mới trên; binary CarFlow dùng các tên selector cũ được mã hóa và cơ chế native scale hiện có. Các API có thể còn thay đổi giữa các bản iOS 18, nên module sẽ bỏ qua hook nếu kiểm tra kiểu không khớp.

## Điều kiện hoạt động

- Chỉ nạp vào `CarPlay` và `CarPlayApp`, không nạp thư viện mới vào SpringBoard hoặc mọi ứng dụng UIKit.
- Chỉ kích hoạt hook trên Darwin 24.x, tương ứng iOS/iPadOS 18.x. Không đoán tương thích với hệ điều hành tương lai.
- Nếu `OmniCarSplitScreen.dylib` hoặc `OmniCarAppBridge.dylib` cũng được nạp vào tiến trình CarPlay, module thử tự ngừng áp dụng để tránh thêm một chuỗi hook cạnh tranh. Muốn test nhánh iOS 18, cần tắt injection của hai thư viện OmniCar trước khi khởi động lại CarPlay; không bắt buộc xóa dữ liệu ứng dụng OmniCar.
- Thư viện dùng các biểu tượng runtime có sẵn trong tiến trình, không hard-code `/var/jb` hoặc đường dẫn `.jbroot-*`.
- Tên package và kiến trúc `iphoneos-arm64e` giữ theo gói CarFlow gốc; binary mới có cả ARM64 và ARM64e.

## Cài thử

1. Giữ sẵn `.deb` CarFlow 1.0.3.4 gốc để quay lại.
2. Cài tệp `CarFlow_1.0.3.4_ios18test1_roothide.deb` qua cùng luồng Sileo/RootHide đã dùng cho gói gốc. Nếu hệ thống của bạn yêu cầu bước chuyển đổi bằng RootHide Patcher, thực hiện như với gói gốc.
3. Respring một lần theo cách bạn thường dùng, rồi kết nối xe.
4. Trên iOS 16/17: kiểm tra CarFlow vẫn mở được, kết nối xe, mở app, chia màn hình, thay cỡ app và kết nối lại như trước. Các hook iOS 18 không chạy trên hai phiên bản này.
5. Trên iOS 18: sau khi tắt injection OmniCar, kiểm tra mở ứng dụng, frame/cỡ app, vùng an toàn, quay lại Dashboard và ngắt/kết nối lại.
6. Nếu CarPlay bị thoát hoặc hình học sai, quay về `.deb` gốc và gửi log/ảnh trạng thái cùng phiên bản iOS đầy đủ. Bản thử có thể làm tiến trình CarPlay thoát; chưa có kiểm chứng trên thiết bị thật.

Quay lại gói gốc sẽ loại bỏ hai tệp `CPR00IOS18Compat.*` qua danh sách tệp dpkg. Không có script tự respring, xóa dữ liệu hoặc sửa hệ thống ngoài các tệp thuộc gói.

## Đọc log

Lọc Console/syslog theo `CarFlow18Compat`:

- `inactive on Darwin 22...` / `23...`: module đã nạp nhưng không cài hook trên iOS 16/17.
- `scoped CarFlow class resolver installed`: đã cài bộ phân giải tên lớp có giới hạn caller.
- `DBDashboard frame selector adapter installed`: đã cài cầu nối frame.
- `DBDashboard inset selector adapter installed`: đã cài cầu nối inset.
- `iOS18 controller lifecycle bridge installed`: đã cài nhánh vòng đời controller thay thế.
- `iOS18 scene-frame bridge reached`: nhánh frame mới đã thực sự được gọi; không đồng nghĩa toàn bộ chức năng đã được kiểm chứng.
- `disabled: OmniCar runtime also loaded`: cần tắt injection OmniCar nếu muốn kiểm tra module này.

## Mã nguồn và build

`src/CarFlowIOS18Compat.c` là mã nguồn mới của lớp cầu nối, không phải mã nguồn gốc phục hồi của CarFlow hoặc OmniCar. `src/policy.h` chứa điều kiện phiên bản/caller và kiểm tra giá trị hình học. Các ABI được đối chiếu với metadata và disassembly của hai gói đã gửi.

Build dùng Zig 0.14.1 làm Clang frontend và `ld64.lld` 19.1.7 làm linker. Không cần header SDK Apple vì module dùng các khai báo C/Objective-C runtime tối thiểu và xác minh kiểu method trước khi dùng. Các tham chiếu runtime được giải quyết từ tiến trình chủ; điều này vẫn cần kiểm tra thực tế bằng loader RootHide trên thiết bị.

```sh
python3 tools/build.py --zig /path/to/zig --ld64 /path/to/ld64.lld --output build
python3 tools/package.py --base /path/to/original/package --module build/CPR00IOS18Compat.dylib --output CarFlow_1.0.3.4_ios18test1_roothide.deb
```

ARM64e được biên dịch bật pointer authentication. LLD 19 ghi subtype đầu ra ARM64_ALL, nên `tools/macho_sign.py` khôi phục subtype khớp object ARM64e rồi tính lại các hash SHA-256 của chữ ký ad-hoc của **thư viện mới**. Công cụ kiểm tra lại từng trang trước khi tạo universal binary. Không ký lại hay sửa header binary CarFlow gốc.

## Giới hạn đã biết

- Chưa chuyển nhánh đồng bộ icon `_SCPAppIconsSyncIOS18`, xử lý dock iOS 18.4+ hoặc toàn bộ logic AppBridge của OmniCar.
- Không cung cấp cơ chế license mới; gói vẫn cần license CarFlow hợp lệ như bản gốc.
- Nếu thiếu symbol hook hoặc API không khớp, module bỏ qua phần đó; không tự tạo hành vi thay thế không có căn cứ.
- Bộ phân giải được cài ngay khi constructor chạy trên main thread. Vẫn cần kiểm tra thứ tự nạp bằng loader RootHide: nếu CarFlow đã khởi tạo trước module mới, các hook khởi tạo một lần của CarFlow có thể bị bỏ lỡ.
- Nếu exception từ framework thoát qua một callback đang xử lý, guard tái nhập có thể giữ module ở đường xử lý gốc đến khi tiến trình khởi động lại.
- Kiểm thử trên Linux xác minh điều kiện, ABI, Mach-O, chữ ký và đóng gói; không thay thế kiểm thử CarPlay trên iPhone.
