# OFFB-Carplay 1.0.3.4+ios18test1.offb1

Bản tùy chỉnh giao diện từ CarFlow test1 theo yêu cầu người dùng. Đã thay biểu tượng ứng dụng bằng ảnh `1a.png` trong tệp người dùng gửi `1a.zip`, đổi tên hiển thị thành **OFFB-Carplay** và số Zalo/gọi hỗ trợ thành **0945070632**.

## Thay đổi

- Hai icon ứng dụng 120×120 và 180×180 dùng ảnh đã cung cấp; ảnh gốc được giữ trong `package/Applications/CPRCompanion.app/OFFBLogo.png`.
- Module `OFFBBranding.dylib` chỉ nạp vào executable `CPRCompanion`. Sau `viewDidLoad`, module đặt logo cùng tên OFFB-Carplay ở tiêu đề của các controller Trang chủ, Trạng thái và Giới thiệu. Nếu module không nạp được, tên và icon trong bundle vẫn đã cấu hình; cần kiểm tra thực tế trên thiết bị.
- Đã thay 37 constant string trên các lát Mach-O của ứng dụng, CPRCarPlayHost và CPRSessionCore: tên sản phẩm, nội dung Zalo/hỗ trợ, liên kết Zalo, liên kết gọi điện và nội dung sao chép số. Chuỗi lưu trữ trong vùng đệm đã ánh xạ của segment `__TEXT`; các con trỏ chained rebase và độ dài NSString được cập nhật tương ứng.
- Các byte mã lệnh và entitlement của ba binary không thay đổi. Đã tính lại chữ ký ad-hoc SHA-1/SHA-256, bao gồm hash các blob yêu cầu/entitlement. Đây không phải chữ ký phát hành của Apple. Giữ bundle ID, package ID, cấu hình license, URL máy chủ và khóa xác thực.
- Module cầu nối iOS 18 giữ nguyên byte so với test1. Nhánh đó chỉ kích hoạt trên iOS 18; chưa chuyển toàn bộ icon/dock/logic AppBridge của OmniCar. Module logo của ứng dụng hoạt động độc lập với điều kiện iOS 18.

## Kiểm tra và thử trên máy

Đã build trên Linux và kiểm tra cấu trúc Mach-O, chữ ký, constant string, plist, kích thước icon và payload sau đóng gói. **Chưa cài hoặc chạy trên iPhone thật.**

Cài `.deb` bằng cùng luồng Sileo/RootHide đã dùng cho gói cũ; dùng RootHide Patcher nếu cách cài hiện tại của máy yêu cầu. Respring, mở OFFB-Carplay, kiểm tra icon và logo ở tiêu đề, mục Giới thiệu, số hỗ trợ và màn xác nhận Zalo/gọi điện. Không có lệnh nào trong quá trình build tự gọi điện hay gửi tin nhắn.

Giữ sẵn CarFlow 1.0.3.4 gốc để khôi phục nếu ứng dụng/CarPlay thoát hoặc hiển thị sai. Trên hai máy iOS 16/17 đã nêu, có thể thử phần tên/logo/liên hệ và hoạt động hiện có; không kiểm chứng được hook tương thích iOS 18. Khi thử nhánh iOS 18, tắt injection OmniCar vào CarPlay theo hướng dẫn test1.

Nếu icon cũ vẫn còn, thực hiện lại bước đăng ký ứng dụng/respring theo luồng RootHide đang dùng; postinst vẫn dùng uicache như gói gốc. Lọc log `OFFBBranding` để xem module logo có cài hook hay không.

## Nội dung và chỉnh sửa

`package/` là cây tệp đã ghép để đóng lại. `src/OFFBBranding.c` và `tools/` là mã nguồn mới/công cụ tùy chỉnh; đây không phải mã nguồn gốc của CarFlow/OmniCar. `analysis/` trong bản xuất đầy đủ vẫn là phân tích binary gốc, nên có tên/số cũ để đối chiếu. `compat-ios18/` chứa mã nguồn cầu nối test1.

Kiểm tra cây xuất trước khi sửa và đóng gói lại trên Linux có Python 3/dpkg-deb:

```sh
python3 tools/verify_export.py
dpkg-deb --root-owner-group -Zxz --build package OFFB-Carplay_tu_chinh.deb
```

Sau khi sửa, manifest sẽ báo các tệp đã thay đổi; đây là dự kiến. Nếu sửa binary cần xử lý lại chữ ký.

Build lại module logo bằng Zig 0.14.1 và LLD 19.1.7:

```sh
python3 tools/build_logo.py --zig /path/to/zig --ld64 /path/to/ld64.lld --output build
cp build/OFFBBranding.dylib package/Library/MobileSubstrate/DynamicLibraries/
```

`tools/brand.py` chỉ dùng để tái tạo phần tên/liên hệ từ **cây CarFlow test1 trước tùy chỉnh**, không chạy lên cây OFFB đã ghép. Logo được tích hợp bằng `tools/finalize.py`, cần ImageMagick và báo cáo build:

```sh
python3 tools/brand.py --base /path/to/carflow-test1/package --output package
python3 tools/build_logo.py --zig /path/to/zig --ld64 /path/to/ld64.lld --output build
python3 tools/finalize.py --package package --logo /path/to/1a.png --module build/OFFBBranding.dylib
dpkg-deb --root-owner-group -Zxz --build package OFFB-Carplay.deb
```

Script từ chối ghi đè thư mục đầu ra trong bước rebrand. Nếu dùng LLD tải riêng trên Linux, cấu hình đường dẫn thư viện LLVM theo toolchain đã cài.
