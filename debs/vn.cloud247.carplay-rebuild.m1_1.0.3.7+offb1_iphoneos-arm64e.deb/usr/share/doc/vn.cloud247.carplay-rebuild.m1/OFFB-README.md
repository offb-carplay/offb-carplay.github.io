# OFFB-Carplay 1.0.3.7+offb1 — bản tùy chỉnh và trích xuất đầy đủ

Bản này dùng trực tiếp gói CarFlow **1.0.3.7** người dùng cung cấp. Người dùng cho biết bản gốc hỗ trợ iOS 15/16/17/18; phiên làm việc này chưa chạy trên thiết bị thật để xác minh từng phiên bản. Các byte mã lệnh của bản gốc được giữ lại khi chỉnh chuỗi tên/liên hệ. Không đưa cầu nối iOS 18 test1 của bản 1.0.3.4 vào gói này.

Đã đổi tên hiển thị thành **OFFB-Carplay**, đổi số Zalo/gọi hỗ trợ và thao tác sao chép số thành **0945070632**, dùng logo `1a.png` trong `1a.zip` đã gửi trước đó. Hai icon có kích thước 120×120/180×180; ảnh gốc nằm trong `package/Applications/CPRCompanion.app/OFFBLogo.png`. Module app riêng thêm logo cùng tên vào tiêu đề Trang chủ/Trạng thái/Giới thiệu.

## Nội dung để chỉnh sửa

- `package/`: toàn bộ cây tệp của bản OFFB đã ghép, gồm DEBIAN, ứng dụng, thư viện và cấu hình. Có thể đóng lại `.deb`.
- `analysis/`: disassembly có chú thích, metadata, constant string, tên lớp/phương thức và chuỗi trong từng lát Mach-O **của gói CarFlow 1.0.3.7 gốc**. Các tên/số cũ trong đây dùng để đối chiếu, không phải nội dung đang hiển thị của bản OFFB.
- `configuration-xml/`: plist của cây package tùy chỉnh được xuất sang XML để đọc; chỉnh tệp trong `package/` khi muốn thay gói cài.
- `src/OFFBBranding.c`: mã nguồn mới của phần hiển thị logo.
- `tools/`: công cụ chỉnh chuỗi, ký lại, build module, phân tích và kiểm tra manifest.
- `branding-report.json`, `reports/`: danh sách chuỗi đã sửa và kết quả xác minh.
- `MANIFEST.json`: SHA-256, kích thước và quyền của mọi tệp trong package. `ORIGINAL-MANIFEST.json`: đối chiếu cây gói gốc.

**Không có mã nguồn Objective-C gốc của CarFlow/OmniCar trong `.deb`.** Bản xuất chứa đầy đủ tệp trích xuất và kết quả phân tích, cùng mã nguồn phần tùy chỉnh mới; không phải dự án có thể biên dịch lại toàn bộ CarFlow từ source. Biến cục bộ, bình luận và cấu trúc dự án gốc không thể phục hồi chính xác bằng giải nén.

Gói CarFlow 1.0.3.7 gốc dùng khôi phục được cung cấp bằng liên kết tải riêng trên cùng trang. SHA-256 gốc:

```text
3a8d6d38a7f6f66698e9c5b3d73ec371e7bc1070660029f057fb4d0d1c4d6ff3
```

## Cài và kiểm tra trên thiết bị

Cài `.deb` OFFB bằng cùng luồng Sileo/RootHide đang dùng cho bản gốc, qua RootHide Patcher nếu quy trình hiện tại yêu cầu. Respring và mở ứng dụng để kiểm tra icon, logo ở tiêu đề, tên và mục liên hệ. Module logo dùng bộ lọc executable CPRCompanion, không nạp thêm vào SpringBoard hoặc CarPlay.

**Chưa chạy trên iPhone thật.** Chữ ký ad-hoc và cấu trúc đã kiểm tra trên Linux; việc nạp module/giao diện trên RootHide cần xác minh thực tế. Giữ sẵn bản gốc để quay lại nếu ứng dụng hoặc CarPlay thoát/hiển thị sai. Lọc log `OFFBBranding` để xem việc cài hook logo. Các script build không gọi điện, gửi tin nhắn hay cài lên iPhone.

Giữ package ID, bundle ID, giá trị phiên bản ứng dụng 1.0.3.7, cấu hình license và máy chủ. Các byte mã lệnh và entitlement của ba binary chỉnh chuỗi không thay đổi; chữ ký được tính lại. Không sửa các nhánh kích hoạt/giấy phép hoặc tự tuyên bố đã kiểm thử đủ bốn phiên bản iOS.

## Đóng gói lại

Trên Linux có Python 3 và dpkg-deb:

```sh
python3 tools/verify_export.py
dpkg-deb --root-owner-group -Zxz --build package OFFB-Carplay_1.0.3.7_tu_chinh.deb
```

Sau khi sửa, manifest sẽ báo tệp khác; đây là dự kiến. Nếu sửa mã máy hoặc chữ ký, cần ký và kiểm tra lại.

Build module logo bằng Zig 0.14.1, ld64.lld 19.1.7:

```sh
python3 tools/build_logo.py --zig /path/to/zig --ld64 /path/to/ld64.lld --output build
cp build/OFFBBranding.dylib package/Library/MobileSubstrate/DynamicLibraries/
```

Tái tạo từ cây gói gốc, trước khi đã chỉnh sửa (cần thêm ImageMagick):

```sh
dpkg-deb -R CarFlow_1.0.3.7_original.deb original-package
python3 tools/brand.py --base original-package --output package
python3 tools/build_logo.py --zig /path/to/zig --ld64 /path/to/ld64.lld --output build
python3 tools/install_logo.py --package package --logo /path/to/1a.png --module build/OFFBBranding.dylib
dpkg-deb --root-owner-group -Zxz --build package OFFB-Carplay_1.0.3.7.deb
```

`brand.py` chỉ nhận control Version 1.0.3.7 và từ chối ghi đè thư mục đầu ra. Công cụ dùng vùng đệm zero đã ánh xạ trong __TEXT để chứa chuỗi mới; giữ trường next của chained rebase, cập nhật target và độ dài constant NSString. Chỉ hỗ trợ các pointer format/CodeDirectory được kiểm tra trong gói đã cung cấp. Những binary được sửa được ký ad-hoc SHA-1/SHA-256, giữ blob entitlement/requirements; không phải chữ ký Apple phát hành.

## Tái tạo phân tích tĩnh

```sh
python3 -m pip install --target tools/pylibs lief capstone
python3 tools/export_analysis.py --package original-package --output analysis
```

Công cụ phân tích không thực thi binary iOS. Chữ ký, ABI và các nhánh có mặt trong mã không thay thế kiểm thử CarPlay trên thiết bị thật.
